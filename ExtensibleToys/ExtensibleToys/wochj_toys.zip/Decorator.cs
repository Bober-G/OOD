﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensibleToys
{
    public abstract class Decorator : IToy
    {
        private readonly IToy _toy;
        public int _jumpsLeft;
        public Decorator(IToy toy)
        {
            _toy = toy;
        }

        public virtual float Cost()
        {
            return _toy.Cost();
        }

        public float Height()
        {
            return _toy.Height();
        }

        public virtual string Summary()
        {
            return _toy.Summary();
        }

        // public float Height()
        // {
        //     toy.summary += $"I am {toy.height} cm high\n";
        //     return toy.height;
        // }
        // public void addDress(string typeOfDress)
        // {
        //     if (typeOfDress == "dotted")
        //     {
        //         toy.summary += $" I have a {typeOfDress} dress.\n";
        //         toy.price += (float)19.99;
        //     }
        //     else if (typeOfDress == "flower")
        //     {
        //         toy.summary += $" I have a {typeOfDress} dress.\n";
        //         toy.price += 20;
        //     }
        //     else
        //     {
        //         Console.WriteLine("Wrong type of dress.\n");
        //     }
        // }


        //public void addJump()
        // {
        //     if(toy.canJump == false)
        //     {
        //         toy.price += 20f;
        //         toy.canJump = true;
        //     }

        //     if(toy.jumpsLeft != 0)
        //     {
        //         toy.summary += $"I can jump! I just jumped {toy.jumpsLeft * 0.1 * toy.height} cm!\n";
        //         toy.jumpsLeft--;
        //     }

        //     //if(toy.jumpsLeft == 0)
        //     //{
        //     //    Console.WriteLine("Toy has no more jumps left ;(");
        //     //}
        // }
     

        //     }
        //     if (typeOfDance == "solo capoeira")
        //     {
        //         if(canCapoeira == false)
        //         {
        //             toy.price += 70;
        //             toy.summary += $"I can dance {typeOfDance}.\n";
        //             canCapoeira = true;
        //         }

        //     }
        //     if (typeOfDance == "gangam style dance")
        //     {
        //         if(canGangamStyle == false)
        //         {
        //             toy.price += 100;
        //             toy.summary += $"I can dance {typeOfDance}.\n";
        //             canGangamStyle = true;
        //         }

        //     }
        // }
        // private bool canTellStory = false;
        // public void addStory(string typeOfStory)
        // {
        //     if(canTellStory == false)
        //     {
        //         canTellStory = true;
        //         toy.price += 30;
        //         if(typeOfStory == "scary")
        //         {
        //             Console.WriteLine($"I can tell {typeOfStory} stories.");
        //         }
        //         if(typeOfStory == "jokes")
        //         {
        //             Console.WriteLine($"I can tell {typeOfStory} stories.");
        //         }
        //     }
        // }


    }
}
