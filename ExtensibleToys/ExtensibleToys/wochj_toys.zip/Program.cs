﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensibleToys
{
    class Program
    {
        static void Main(string[] args)
        {

            //Adding collection of dresses, dances and stories
            string[] dressPattern = { "dotted", "flower" };
            string[] danceStyles = { "breakdance", "solo capoeira", "gangam style dance"};
            string[] storyTypes = { "scary", "jokes"};

            IToy doll = new Doll();
            IToy warrior = new Warrior();
            IToy raceDriver = new RaceDriver();
            IToy minotaur = new Minotaur("alan", 10, 100);
            IToy centaur = new Centaur("darek", 8, false);

            Console.WriteLine("Printing basic Summaries and Prices of toys.\n");
            Console.WriteLine($"{doll.Summary()}, Price:{doll.Cost()}");
            Console.WriteLine($"{warrior.Summary()}, Price:{warrior.Cost()}");
            Console.WriteLine($"{raceDriver.Summary()}, Price:{raceDriver.Cost()}");
            Console.WriteLine($"{minotaur.Summary()}, Price:{minotaur.Cost()}");
            Console.WriteLine($"{centaur.Summary()}, Price:{centaur.Cost()}");

            Console.WriteLine("\ntesting the elements i can add to toys.\n");
            Decorator Warrior = new Helmet(warrior);
            Warrior = new Dress(Warrior, dressPattern[1]);
            Warrior = new Dance(Warrior, danceStyles[0]);
            Warrior = new Dance(Warrior, danceStyles[2]);
            Warrior = new Story(Warrior, storyTypes[1]);
            Warrior = new Jump(Warrior);
            Console.WriteLine(Warrior.Summary());
            Console.WriteLine($"Price: {Warrior.Cost()}");

            Decorator RaceDriver = new Sword(raceDriver);
            RaceDriver = new Dress(RaceDriver, dressPattern[1]);
            RaceDriver = new Helmet(RaceDriver);
            Console.WriteLine($"{RaceDriver.Summary()}, Price:{RaceDriver.Cost()}");

            Console.WriteLine("\ntesting adding at least 6 jumps.\n");
            Decorator Doll = new Jump(doll);
            //1
            Console.WriteLine(Doll.Summary());
            Console.WriteLine($"Price: {Doll.Cost()}");
            //2
            Console.WriteLine(Doll.Summary());
            Console.WriteLine($"Price: {Doll.Cost()}");
            //3
            Console.WriteLine(Doll.Summary());
            Console.WriteLine($"Price: {Doll.Cost()}");
            //4
            Console.WriteLine(Doll.Summary());
            Console.WriteLine($"Price: {Doll.Cost()}");
            //5
            Console.WriteLine(Doll.Summary());
            Console.WriteLine($"Price: {Doll.Cost()}");
            //6
            Console.WriteLine(Doll.Summary());
            Console.WriteLine($"Price: {Doll.Cost()}");
             
             Console.WriteLine("\ntesting adding multiple dances.\n");

            Decorator Minotaur = new Dance(minotaur, danceStyles[0]);
            Minotaur = new Dance(Minotaur, danceStyles[2]);
            Console.WriteLine($"{Minotaur.Summary()}, Price:{Minotaur.Cost()}");





        }
    }
}
