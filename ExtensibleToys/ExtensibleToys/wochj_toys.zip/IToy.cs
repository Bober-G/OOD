﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExtensibleToys
{
    public interface IToy
    {
        float Cost();
        string Summary();

        public float Height();
       
        

    }
}
